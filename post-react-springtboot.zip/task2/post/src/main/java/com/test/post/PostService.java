package com.test.post;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PostService {
	@Autowired
	PostRepository repo;
	public Post insertPost(Post post)
	{
		return repo.save(post);
	}
	
	public Post fetchPost(Long Id)
	{
		return repo.findById(Id).get();
	}
	
	public List<Post> fetchAllPost()
	{
		return repo.findAll();
	}
	
	public void deletePost(Long Id)
	{
		 repo.deleteById(Id);
	}
}
