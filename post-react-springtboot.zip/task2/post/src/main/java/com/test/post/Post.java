package com.test.post;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Post {
	
	@Id
	Long postId;
	String postName;
	String postedBy;
	
	Post(Long postId, String postName, String postedBy)
	{
		this.setPostId(postId);
		this.setPostedBy(postedBy);
		this.setPostName(postName);
	}
	
	public Long getPostId() {
		return postId;
	}
	public void setPostId(Long postId) {
		this.postId = postId;
	}
	public String getPostName() {
		return postName;
	}
	public void setPostName(String postName) {
		this.postName = postName;
	}
	public String getPostedBy() {
		return postedBy;
	}
	public void setPostedBy(String postedBy) {
		this.postedBy = postedBy;
	}
	
	

}
