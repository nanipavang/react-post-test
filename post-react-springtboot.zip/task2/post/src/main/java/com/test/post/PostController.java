package com.test.post;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PostController {
	@Autowired
	PostService postService;
	
	@PostMapping(value="/insertpost")
	public Post insertPost(Post post)
	{
		return postService.insertPost(post);
	}
	
	@GetMapping("/fetchpost/{Id}")
	public Post fetchPost(@PathVariable Long Id)
	{
		return postService.fetchPost(Id);
	}
	
	@GetMapping("/fetchallposts")
	public List<Post> fetchAllPost()
	{
		return postService.fetchAllPost();
	}
	
	@DeleteMapping("/deletepost/{Id}")
	public void deletePost(@PathVariable Long Id)
	{
		postService.deletePost(Id);
	}
}
